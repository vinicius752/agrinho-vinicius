let questions = [];
let currentQuestion = 0;
let score = 0;
let feedback = "";
let feedbackTime = 0;

function setup() {
  createCanvas(800, 400);
 
  // Cria as perguntas
  questions = [
    { 
      question: "O campo e cidade são epaços independentes, sem relação entre si?", 
      answer: false 
    },
    {
     question: "A cidade depende do campo para obter matérias primas?",       
     answer: true 
    },  
    {       
    question: "A vida no campo tem maior agitação e poluição do que a cidade?",    
    answer: false    
    },    
    {          
    question: "A cidade é mais populosa e possui mais infraestrutura urbana que o campo?",             answer: true    
    },
    {
    question: "Desmatar as florestas ajuda preservar animais? ",
    answer:false
    },
    {
    question: "A água é um recurço natural que nunca acaba?",
    answer:true
    },
    {
    question: "A comunicação entre o campo e a cidade é importante para o comércio de alimentos?",
    answer:true
    },
    {
    question: "A cidade não precisa do campo para nada?",
    answer:false
    },
    {
    question: "A tecnologia ajudou a aproximar o campo e a cidade?",
    answer:true
    },
    {
    question: "O campo produz alimentos que abastecem a cidade?",
    answer:true
    },
    {
    question: "Quando colaboram, campo e cidade constroem um país mais forte?",
    answer:true
    }
  ];
}

function draw() {
  background("rgb(166,231,166)");
 
  if (currentQuestion < questions.length) {
    // Mostra a pergunta atual
    textSize(24);
    textAlign(CENTER);
    fill(0);
    text (" Festejando a conexão campo e cidade, questionário :", width / 2,40 )
    text(questions[currentQuestion].question, width/2, height/3);
   
    // Desenha botões
    drawButton("Verdadeiro", width/2 - 120, height/2 + 50, color(0, 200, 0));
    drawButton("Falso", width/2 + 20, height/2 + 50, color(200, 0, 0));
   
    // Mostra feedback
    if (feedback !== "") {
      textSize(32);
      fill(feedback === "Correto!" ? color(0, 200, 0) : color(200, 0, 0));
      text(feedback, width/2, height/2 + 150);
     
      // Avança após 1 segundo
      if (millis() - feedbackTime > 1000) {
        currentQuestion++;
        feedback = "";
      }
    }
  } else {
    // Tela final
    textSize(32);
    fill(0);
    text("Fim do Jogo!", width/2, height/3);
    text(`Pontuação: ${score}/${questions.length}`, width/2, height/2);
  }
}

function drawButton(label, x, y, col) {
  fill(col);
  rect(x, y, 100, 50, 5);
  fill(255);
  textSize(20);
  text(label, x + 50, y + 30);
}

function mousePressed() {
  if (currentQuestion >= questions.length) return;
 
  let trueButton = {x: width/2 - 120, y: height/2 + 50, w: 100, h: 50};
  let falseButton = {x: width/2 + 20, y: height/2 + 50, w: 100, h: 50};
 
  if (feedback === "") {
    // Verifica clique no botão Verdadeiro
    if (mouseX > trueButton.x && mouseX < trueButton.x + trueButton.w &&
        mouseY > trueButton.y && mouseY < trueButton.y + trueButton.h) {
      checkAnswer(true);
    }
   
    // Verifica clique no botão Falso
    if (mouseX > falseButton.x && mouseX < falseButton.x + falseButton.w &&
        mouseY > falseButton.y && mouseY < falseButton.y + falseButton.h) {
      checkAnswer(false);
    }
  }
}

function checkAnswer(answer) {
  if (answer === questions[currentQuestion].answer) {
    score++;
    feedback = "Correto!";
  } else {
    feedback = "Errado!";
  }
  feedbackTime = millis();
}
